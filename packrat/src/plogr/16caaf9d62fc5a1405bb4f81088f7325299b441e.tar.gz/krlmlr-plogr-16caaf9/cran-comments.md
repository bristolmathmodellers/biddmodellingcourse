## Test environments
* local Ubuntu 16.04 install, R 3.3.1
* ubuntu 12.04, 14.04 (on travis-ci), R 3.3.1
* OS X (on travis-ci), R 3.3.1
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 1 note

* This is a new release under MIT license. The packaged library is licensed under Mozilla Public License 2.0; I believe redistribution under MIT license is possible, but I don't have a good understanding of OSS licenses.

* Resubmission with corrected package description.

## Reverse dependencies

This is a new release, so there are no reverse dependencies.
