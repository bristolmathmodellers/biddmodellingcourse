library(testthat)
library(multidplyr)

test_check("multidplyr")
