library(testthat)
library(bindr)

test_check("bindr")
