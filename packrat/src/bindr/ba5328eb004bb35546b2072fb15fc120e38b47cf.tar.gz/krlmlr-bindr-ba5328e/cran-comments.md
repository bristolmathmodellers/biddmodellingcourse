## Test environments
* local ubuntu 17.10 install, R 3.4.3
* ubuntu 12.04 (on travis-ci), R devel, release, and oldrel
* win-builder (devel and release)

## R CMD check results

OK

## Reverse dependencies

Run checks successfully on bindrcpp, the only downstream dependencies.
