library(testthat)
library(ggjoy)

test_check("ggjoy")
