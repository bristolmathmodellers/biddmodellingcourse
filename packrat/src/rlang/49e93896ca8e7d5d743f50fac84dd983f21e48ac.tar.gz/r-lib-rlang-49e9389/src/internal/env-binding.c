#include <rlang.h>

bool rlang__env_binding_is_promise(sexp* env, sexp* sym) {
  if (r_typeof(sym) != r_type_symbol) {
    r_abort("Internal error: Expected symbol in active binding predicate");
  }

  sexp* obj = r_env_find(env, sym);
  return r_typeof(obj) == r_type_promise && PRVALUE(obj) == r_unbound_sym;
}

sexp* rlang_env_binding_are_promise(sexp* env, sexp* syms) {
  if (r_typeof(syms) != r_type_list) {
    r_abort("Internal error: Expected list of symbols in active binding predicate");
  }

  size_t n = r_vec_length(syms);
  sexp* out = KEEP(r_new_vector(r_type_logical, n));
  int* out_array = r_lgl_deref(out);

  for (size_t i = 0; i < n; ++i) {
    sexp* sym = r_list_get(syms, i);
    out_array[i] = rlang__env_binding_is_promise(env, sym);
  }

  FREE(1);
  return out;
}
