## Test environments
* local OS X install, R 3.4.1
* ubuntu 12.04 (on travis-ci), R 3.4.1
* win-builder (devel)

## R CMD check results
0 errors | 0 warnings | 0 notes

## Reverse dependencies

I ran revdep checks on the 272 reverse dependencies (complete results at
https://github.com/hadley/scales/blob/master/revdep). There were issues with
three packages; one of these issues appears unrelated to `scales`, and one has
since been fixed. The maintainer of the `incidence` package was notified of the
issue that is related to `scales` changes on 10 August 2017.
